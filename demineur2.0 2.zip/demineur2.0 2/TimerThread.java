public class TimerThread extends Thread{
    public static int millisecondes = 0;
    public void run(){
        while(true){
            try{
            Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            millisecondes++; //Compteur de millisecondes
        }
    }
}
