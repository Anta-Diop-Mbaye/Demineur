import javax.swing.SwingUtilities;
public class Main{
    public static void main(String[] args) {

      TimerThread timer = new TimerThread();
        timer.start();
      SwingUtilities.invokeLater(new Runnable() {
        public void run(){
                new Frame("Demineur");
        //new Interface();
            }
        });


    }

}






